import numpy as np
import matplotlib.pyplot as plt
import os
# 创建示例数组
input = np.array([[[1, 2], [3, 4], [5, 6]],
                  [[7, 8], [9, 10], [11, 12]]])

true = np.array([[[13, 14], [15, 16], [17, 18]],
                 [[19, 20], [21, 22], [23, 24]]])
# 进行连接操作
gt = np.concatenate((input[0, :, -1], true[0, :, -1]), axis=0)
print(gt)
x = [1, 2, 3, 4, 5]
y = [2, 3, 5, 7, 11]
plt.figure()
plt.plot(x, label='GroundTruth', linewidth=2)
plt.plot(y, label='Prediction', linewidth=2)
plt.legend()
save_path = os.path.join("C:/Users/DU15/Desktop/Autoformer-main/ceshi", "00.pdf")
plt.savefig(save_path, bbox_inches='tight')