import pandas as pd
import os
import numpy as np
import json
import time
import shutil
import math
import glob
import ast

def hex_bin(file):

    df = pd.read_csv(file, dtype={'data': str, 'dlc': int, 'time': float})
    df['data'] = df['data'].str.replace(" ", "").apply(lambda x: bin(int(x, 16))[2:])
    df['dlc'] = df['dlc'].apply(lambda x: int(x))  # 将dlc列的值转换为整数
    df['data'] = df.apply(lambda row: (row['data']).zfill(row['dlc'] * 8), axis=1)
    df['data'] = '\t' + df['data']

    return df


def sort_ID(df):
    output_folder = 'sort_ID'
    os.makedirs(output_folder, exist_ok=True)
    grouped = df.groupby('id')

    for group_name, group_data in grouped:
        file_name = f'{group_name}.csv'
        file_path = os.path.join(output_folder, file_name)
        group_data.to_csv(file_path, index=False)


def PreProcessing(NewfilePath, name):
        filePath = os.path.join(NewfilePath, name)
        data = pd.read_csv(filePath, dtype={'data': str})
        dlc = data.loc[0, 'dlc'] * 8  # 获取数据段的长度
        data = data.loc[:, 'data']
        data0 = data[0]  # 作为是否翻转的标准
        data0 = data0.replace('\t', '')

        bitFlip = [0] * dlc

        real_bitFlip = [0] * dlc
        magnitude = [0] * dlc
        relative_bitFlip = [0] * dlc
        zero_to_one_relative_bitFlip = [0] * dlc
        one_to_zero_relative_bitFlip = [0] * dlc
        one_to_two_relative_bitFlip = [0] * dlc
        two_to_one_relative_bitFlip = [0] * dlc
        relative_bitFlip_divide_bitFlip = [0] * dlc
        zero_to_one_relative_bitFlip_divide_relative_bitFlip = [0] * dlc
        one_to_zero_relative_bitFlip_divide_relative_bitFlip = [0] * dlc
        one_to_two_relative_bitFlip_divide_relative_bitFlip = [0] * dlc
        two_to_one_relative_bitFlip_divide_relative_bitFlip = [0] * dlc

        count = 0
        for datai in data:
            datai = datai.replace('\t', '')
            for j in range(0, dlc):
                if datai[j] != data0[j]:
                    bitFlip[j] += 1
                    real_bitFlip[j] += 1
                if j < dlc - 1:
                    if datai[j] != data0[j] and datai[j + 1] != data0[j + 1]:
                        relative_bitFlip[j] += 1
                        if datai[j] == datai[j + 1] and data0[j] == data0[j + 1] and datai[j] == '1':
                            zero_to_one_relative_bitFlip[j] += 1
                        if datai[j] == datai[j + 1] and data0[j] == data0[j + 1] and datai[j] == '0':
                            one_to_zero_relative_bitFlip[j] += 1
                        if datai[j] == '1' and datai[j + 1] == '0' and data0[j] == '0' and data0[j + 1] == '1':
                            one_to_two_relative_bitFlip[j] += 1
                        if datai[j] == '0' and datai[j + 1] == '1' and data0[j] == '1' and data0[j + 1] == '0':
                            two_to_one_relative_bitFlip[j] += 1
            data0 = datai
        for i in range(0, dlc - 1):
            if bitFlip[i] != 0:
                relative_bitFlip_divide_bitFlip[i] = relative_bitFlip[i] / real_bitFlip[i]
            else:
                relative_bitFlip_divide_bitFlip[i] = 100
            if relative_bitFlip[i] != 0:
                zero_to_one_relative_bitFlip_divide_relative_bitFlip[i] = zero_to_one_relative_bitFlip[i] / \
                                                                          relative_bitFlip[i]
            else:
                zero_to_one_relative_bitFlip_divide_relative_bitFlip[i] = 100
            if relative_bitFlip[i] != 0:
                one_to_zero_relative_bitFlip_divide_relative_bitFlip[i] = one_to_zero_relative_bitFlip[i] / \
                                                                          relative_bitFlip[i]
            else:
                one_to_zero_relative_bitFlip_divide_relative_bitFlip[i] = 100
            if relative_bitFlip[i] != 0:
                one_to_two_relative_bitFlip_divide_relative_bitFlip[i] = one_to_two_relative_bitFlip[i] / \
                                                                         relative_bitFlip[i]
            else:
                one_to_two_relative_bitFlip_divide_relative_bitFlip[i] = 100
            if relative_bitFlip[i] != 0:
                two_to_one_relative_bitFlip_divide_relative_bitFlip[i] = two_to_one_relative_bitFlip[i] / \
                                                                         relative_bitFlip[i]
            else:
                two_to_one_relative_bitFlip_divide_relative_bitFlip[i] = 100
        for i in range(0, dlc):
            bitFlip[i] = bitFlip[i] / data.size
            if bitFlip[i] == 0:
                magnitude[i] = -100
            else:
                logx = math.log(bitFlip[i], 10)
                magnitude[i] = math.ceil(logx)
        return [bitFlip,
                dlc,
                magnitude,
                real_bitFlip,
                relative_bitFlip,
                relative_bitFlip_divide_bitFlip,
                zero_to_one_relative_bitFlip,
                zero_to_one_relative_bitFlip_divide_relative_bitFlip,
                one_to_zero_relative_bitFlip,
                one_to_zero_relative_bitFlip_divide_relative_bitFlip,
                one_to_two_relative_bitFlip,
                one_to_two_relative_bitFlip_divide_relative_bitFlip,
                two_to_one_relative_bitFlip,
                two_to_one_relative_bitFlip_divide_relative_bitFlip
                ]


def sensorExtractor(prevResult):
    bitFlip = prevResult[0]
    dlc = prevResult[1]
    magnitude = prevResult[2]
    bitFlip_origin = prevResult[3]
    relative_bitflip = prevResult[4]
    r_div_o_bitfilp = prevResult[5]
    zero_to_one_relative_bitFlip = prevResult[6]
    z2o = prevResult[7]
    one_to_zero_relative_bitFlip = prevResult[8]
    o2z = prevResult[9]
    o2t = prevResult[11]
    t2o = prevResult[13]
    i = 0
    start = 0
    end = 0
    ref = []
    k = 0
    while i < dlc - 1:
        if r_div_o_bitfilp[i] == 1.0:
            start = i
            for j in range(i, dlc-1):
                if 1.5 * r_div_o_bitfilp[j] >= r_div_o_bitfilp[j + 1] and j < dlc-2:
                    end = j+1
                else:
                    i = j
                    if end == dlc - 2 and (r_div_o_bitfilp[end] <= 1.5*r_div_o_bitfilp[end-1]):
                        end += 1
                    if end - start >= 2:  # limit the length of extracted data(make sure it's length no less than 3bits)



                        # Signedness
                        Signedness = []
                        extrame_change_counter = 0  # 从头开始，出现（00变11为0.5和11变00为0.5）的比特的计数
                        for l in range(start, end):
                            if z2o[start] + o2z[start] != 1.0:
                                break
                            if (z2o[l] + o2z[l] == 1) and (bitFlip[l] == bitFlip[l+1]):
                                extrame_change_counter += 1
                        if extrame_change_counter >= 2 and end - start >= 7:
                            Signedness = ['Signed']
                        else:
                            Signedness = ['Unsigned']
                        # Signedness
                        if end - start > 4:
                            if k != 0:
                                while ((start % 8 != 0) and (start % 8 != 7) and (start > (ref[k-1][0][1]+1))):
                                    start = start - 1
                            else:
                                while ((start % 8 != 0) and (start % 8 != 7)):
                                    start = start - 1
                        k = k + 1
                        Boundary = [start, end]
                        Signal_attribute = [Boundary, Signedness]
                        ref.append(Signal_attribute)

                    break
        i += 1

    if ref != []:
        if ((ref[-1][0][1] - ref[-1][0][0]) > 16) and (ref[-1][0][1] == 63):
            if (ref[-1][0][1] - ref[-1][0][0]) < 21:
                ref[-1][0][1] = 59
                ref.append([[60, 63], ['Unsigned']])
            else:
                ref[-1][0][1] = 55
                ref.append([[56, 63], ['Unsigned']])

    print(ref)
    return ref

def crateNewData(filePath, name, classifyI, output_folder):
    index = classifyI
    filePath = os.path.join(filePath, name)
    data = pd.read_csv(filePath, dtype={'data': str, 'dlc': int, 'time':float})

    newData10 = data.loc[:, ['time', 'dlc']]
    temp = data.loc[:, ['time', 'dlc']]
    j = 0
    for attribute in index:
        i = attribute[0]
        signedness = attribute[1]
        dataName = 'physical_sign'
        start = i[0] + 1  # +1的原因是，存入csv时需要使数据变为str类型，所有在每个data前面加一个\t，通过往后平移一个，可以获得真正的data
        end = i[1] + 2
        temp[dataName] = data['data'].str.slice(start, end)
        if signedness == ['Signed']:
            for v in range(temp[dataName].size):
                if temp[dataName][v][0] == '1':
                    de_sign_list = []
                    for bit_pos in range(0, len(temp[dataName][v])):
                        if temp[dataName][v][bit_pos] == '0':
                            de_sign_list.append('1')
                        else:
                            de_sign_list.append('0')
                    de_sign = ''.join(de_sign_list)
                    newData10.at[v, dataName] = str(int(de_sign, 2) * -1)
                else:
                    de_sign = temp[dataName][v]
                    newData10.at[v, dataName] = str(int(de_sign, 2))
        else:
            for v in range(temp[dataName].size):
                newData10.at[v, dataName] = str(int(temp[dataName][v], 2))
        column_name = "physical_sign"
        finalData = newData10.loc[:, ['time', column_name, 'dlc']]
        name1 = name.split('.')
        hex_name = name1[0]
        finalData['id'] = hex_name + "_" + str(j)
        finalData = finalData[['id', 'dlc', 'time', column_name]]
        file_path = os.path.join(output_folder, f"{hex_name}-data{j}.csv")
        finalData.to_csv(file_path, index=False)
        j = j + 1

def time_sort(folder_path, output_folder):
    all_data = pd.DataFrame()
    for file_name in os.listdir(folder_path):
        if file_name.endswith('.csv'):
            file_path = os.path.join(folder_path, file_name)
            df = pd.read_csv(file_path, dtype=object)
            all_data = pd.concat([all_data, df], ignore_index=True)

    all_data = all_data.sort_values(by='time')

    os.makedirs(output_folder, exist_ok=True)

    if os.listdir(output_folder):
        shutil.rmtree(output_folder)
        os.makedirs(output_folder)

    output_file = os.path.join(output_folder, 'sorted_combined_data.csv')
    all_data.to_csv(output_file, index=False)


def list_csv_files(directory):
    files = os.listdir(directory)
    csv_files = [os.path.splitext(file)[0].replace('-data', '_') for file in files if file.endswith('.csv')]

    return csv_files



def convert2csv(time_path, result_filer):
    for file_name in os.listdir(time_path):
        time_filer = os.path.join(time_path, file_name)
    df = pd.read_csv(time_filer)

    unique_ids = list_csv_files(result_filer)

    num_timestamps = len(df) // 50
    print(num_timestamps)
    matrix = pd.DataFrame(columns=unique_ids)
    for i in range(num_timestamps):
        start_idx = i * 50
        end_idx = (i + 1) * 50
        timestamp_data = df.iloc[start_idx:end_idx]

        for j, id_value in enumerate(unique_ids):
            id_data = timestamp_data[timestamp_data['id'] == str(id_value)]
            if not id_data.empty:
                matrix.loc[i, id_value] = str(id_data['physical_sign'].values[0])  # 填充数据到矩阵的对应位置
            else:
                matrix.loc[i, id_value] = 0

    df_matrix = pd.DataFrame(matrix, columns=unique_ids)
    df_matrix.to_csv("final_result.csv", index=False)


def READ(NewfilePath, name):
    filePath = os.path.join(NewfilePath, name)
    data = pd.read_csv(filePath, dtype={'data': str})
    dlc = data.loc[0, 'dlc'] * 8  # 获取数据段的长度
    data = data.loc[:, 'data']
    payloadLen = len(data)
    binary_Data = []
    bitFlip = [0] * dlc
    magnitude = [0] * dlc

    for j in range(payloadLen - 2):
        previous = data[j]
        item = data[j + 1]
        for i in range(dlc):
            if item[i+1] != previous[i+1]:
                bitFlip[i] += 1

    for i in range(dlc):
        bitFlip[i] /= payloadLen
        if bitFlip[i] != 0:
            magnitude[i] = math.ceil(math.log2(bitFlip[i]))
        else:
            magnitude[i] = 1

    ref = []
    prevMagnitude = magnitude[0]
    ixS = 0

    for i in range(1, dlc):
        if magnitude[i] < prevMagnitude:
            ref.append((ixS, i - 1))
            ixS = i
        prevMagnitude = magnitude[i]

    ref.append((ixS, dlc - 1))



    return ref


def read_crateNewData(filePath, name, classifyI, output_folder):
    index = classifyI
    filePath = os.path.join(filePath, name)
    data = pd.read_csv(filePath, dtype={'data': str, 'dlc': int})

    newData10 = data.loc[:, ['time', 'dlc']]
    temp = data.loc[:, ['time', 'dlc']]
    j = 0
    for attribute in index:

        dataName = 'physical_sign'
        #dataName = dataName + str(j)  # 每列的名称
        start = attribute[0] + 1
        end = attribute[1] + 2
        temp[dataName] = data['data'].str.slice(start, end)
        for v in range(temp[dataName].size):
            newData10.at[v, dataName] = str(int(temp[dataName][v], 2))
        column_name = "physical_sign"
        finalData = newData10.loc[:, ['time', column_name, 'dlc']]
        name1 = name.split('.')
        hex_name = name1[0]
        finalData['id'] = hex_name + "_" + str(j)
        finalData = finalData[['id', 'dlc', 'time', column_name]]
        file_path = os.path.join(output_folder, f"{hex_name}-data{j}.csv")

        finalData.to_csv(file_path, index=False)
        j = j + 1