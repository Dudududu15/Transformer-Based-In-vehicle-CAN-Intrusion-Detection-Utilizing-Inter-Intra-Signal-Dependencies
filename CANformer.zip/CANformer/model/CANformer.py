import torch
import torch.nn as nn
from layers.Embed import TrendEmbedding
from layers.AutoCorrelation import AutoCorrelation, AutoCorrelationLayer
from layers.TokenEncoderlayer import Encoder, EncoderLayer, my_Layernorm
from layers.Transformer_Enc import Trans_Encoder, Trans_EncoderLayer, series_decomp
from layers.Attention import FullAttention, AttentionLayer

class Model(nn.Module):
    """
    Autoformer is the first method to achieve the series-wise connection,
    with inherent O(LlogL) complexity
    """
    def __init__(self, configs):
        super(Model, self).__init__()
        self.k = configs.top_k
        # parameter-efficient design

        self.configs = configs
        self.seq_len = configs.seq_len
        self.label_len = configs.label_len
        self.pred_len = configs.pred_len
        self.enc_in = configs.enc_in
        self.output_attention = configs.output_attention
        kernel_size = configs.moving_avg
        self.decomp = series_decomp(kernel_size)
        self.trend_embedding = TrendEmbedding(configs.seq_len, configs.d_model, configs.embed, configs.freq,
                                                    configs.dropout)

        self.encoder = Encoder(
            [
                EncoderLayer(
                    AutoCorrelationLayer(
                        AutoCorrelation(False, configs.factor, attention_dropout=configs.dropout,
                                        output_attention=configs.output_attention),
                        configs.d_model, configs.n_heads, configs.seq_len, configs.pred_len),
                    configs.d_model,
                    configs.c_out,
                    configs.d_ff,
                    moving_avg=configs.moving_avg,
                    dropout=configs.dropout,
                    activation=configs.activation
                ) for l in range(configs.e_layers)
            ],
            norm_layer=my_Layernorm(configs.d_model),
            projection = nn.Linear(configs.d_model, configs.c_out, bias=True)
        )

        self.Trans_encoder = Trans_Encoder(
            [
                Trans_EncoderLayer(
                    AttentionLayer(
                        FullAttention(False, configs.factor, attention_dropout=configs.dropout,
                                      output_attention=configs.output_attention), configs.d_model, configs.n_heads),
                    configs.d_model,
                    configs.d_ff,
                    dropout=configs.dropout,
                    activation=configs.activation
                ) for l in range(configs.e_layers)
            ],
            norm_layer=torch.nn.LayerNorm(configs.d_model)
        )
        self.projector = nn.Linear(configs.d_model, configs.seq_len, bias=True)
        self.predict_linear = nn.Linear(self.seq_len, self.pred_len + self.seq_len)
        self.k = configs.top_k
        self.layer = configs.e_layers
        self.layer_norm = nn.LayerNorm(configs.d_model)
        self.projection = nn.Linear(
            configs.d_model, configs.c_out, bias=True)

    def forward(self, x_enc,
                enc_self_mask=None, dec_self_mask=None, dec_enc_mask=None):
        # decomp init
        _, L, N = x_enc.shape
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(
            torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc /= stdev
        dec_in = x_enc

        #seasonality block
        seasonal_init, _ = self.decomp(x_enc)
        for i in range(self.enc_in):
            season_x = seasonal_init[:, :, i]
            res, attns = self.encoder(season_x, attn_mask=enc_self_mask)
            dec_in[:, :, i] = res + x_enc[:, :, i]
        muti_x_enc = self.trend_embedding(dec_in)

        #correlation
        multi_correlations, attns = self.Trans_encoder(muti_x_enc, attn_mask=None)
        dec_out = self.projector(multi_correlations).permute(0, 2, 1)[:, :, :N]

        if self.output_attention:
            return dec_out[:, -self.seq_len:, :], attns
        else:
            return dec_out[:, -self.seq_len:, :]